//Ryan Melville , Yuan Wen AI Prog 4

package Unary;
public enum TypeUnaryConstraint{
	inclusive, exclusive
}