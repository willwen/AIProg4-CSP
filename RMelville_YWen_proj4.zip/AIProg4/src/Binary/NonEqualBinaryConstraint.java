package Binary;

import java.util.ArrayList;

import Main.Item;

public class NonEqualBinaryConstraint extends AbsBinaryConstraint {

	public NonEqualBinaryConstraint(TypeBinaryConstraint type,
			ArrayList<Item> variables) {
		super(type, variables);
		// TODO Auto-generated constructor stub
	}

}
