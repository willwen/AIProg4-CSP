package Binary;

public enum TypeBinaryConstraint {
	equal, mutualEx, nonEqual
}
