//Ryan Melville , Yuan Wen AI Prog 4

package Main;

public class FitLimit {
	int minItems;
	int maxItems;
	public FitLimit(int min, int max){
		minItems = min;
		maxItems = max;
	}
}
